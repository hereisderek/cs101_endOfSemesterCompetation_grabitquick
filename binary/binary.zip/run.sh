#!sh
cd ./bin
pwd
java A3 
